/*
 * Copyright (c) 2004-2007 The Trustees of the University of Tennessee.
 *                         All rights reserved.
 * $COPYRIGHT$
 *
 * Additional copyrights may follow
 *
 * $HEADER$
 */

#include "ompi_config.h"
#include "vprotocol_pessimist_event.h"

OBJ_CLASS_INSTANCE(mca_vprotocol_pessimist_event_t, opal_list_item_t, NULL, NULL);
