From:
http://iconeden.com/icon/milky-a-free-vector-iconset.html

License Agreement

This is a legal agreement between you (the downloader) and IconEden.com. On download of any royalty-free icons from our website you agree to the following:

All of the icons remain the property of IconEden.com. The icons can be used royalty-free by the license for any personal or commercial project including web application, web design, software application, mobile application, documentation, presentation, computer game, advertising, film, video.

You may modify the icons in shape, color, and/or file format and use the modified icons royalty-free according to the license terms for any personal or commercial product.

The license does not permit the following uses:

   1. The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use or detached from a product, software application or web page;
   2. The icons may not be placed on any electronic bulletin board or downloadable format;

You may not use, or allow anyone else to use the icons to create pornographic, libelous, obscene, or defamatory material.

All icon files are provided "as is". You agree not to hold IconEden.com liable for any damages that may occur due to use, or inability to use, icons or image data from IconEden.com.
