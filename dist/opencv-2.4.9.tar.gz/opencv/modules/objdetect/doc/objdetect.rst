***************************
objdetect. Object Detection
***************************

.. highlight:: cpp

.. toctree::
    :maxdepth: 2

    cascade_classification
    latent_svm
