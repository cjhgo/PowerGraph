********************************
nonfree. Non-free functionality
********************************

The module contains algorithms that may be patented in some countries or have some other limitations on the use.

.. toctree::
    :maxdepth: 2

    feature_detection
